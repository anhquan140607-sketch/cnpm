class ContestResult {
  final String id;
  final String contestTitle;
  final String submissionTitle;
  final double score;
  final String prize;
  final String judgeFeedback;
  final String status;
  final DateTime announcedDate;

  ContestResult({
    required this.id,
    required this.contestTitle,
    required this.submissionTitle,
    required this.score,
    required this.prize,
    required this.judgeFeedback,
    required this.status,
    required this.announcedDate,
  });
}
