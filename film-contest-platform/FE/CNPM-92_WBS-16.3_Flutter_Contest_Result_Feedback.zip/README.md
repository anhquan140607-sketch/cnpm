# [CNPM-92 / WBS 16.3] Flutter: Hiển thị kết quả và nhận xét của giám khảo (FE16 - SRS FR-16.3)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                       # Điểm khởi chạy ứng dụng
├── models/
│   └── result_model.dart           # Model dữ liệu kết quả chấm thi & nhận xét
└── screens/
    └── contest_result_screen.dart  # Màn hình danh sách kết quả, điểm số, giải thưởng & nhận xét chi tiết của giám khảo (SRS FR-16.3)
```

## 2. Tính năng chính đáp ứng SRS FR-16.3
- **Xem điểm số & giải thưởng**: Thí sinh sau khi có kết quả công bố có thể xem trực tiếp số điểm chấm trên thang điểm 10 cùng danh hiệu giải thưởng đạt được.
- **Nhận xét chi tiết từ giám khảo**: Bấm vào từng bài thi để mở giao diện Modal Bottom Sheet xem lời nhận xét, đánh giá kỹ thuật chi tiết từ Hội đồng Giám khảo.
