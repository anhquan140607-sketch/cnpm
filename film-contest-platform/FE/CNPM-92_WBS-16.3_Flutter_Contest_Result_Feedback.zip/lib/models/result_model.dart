class ContestResult {
  final String id;
  final String contestTitle;
  final String submissionTitle;
  final double score; // Thang điểm 10 hoặc 100
  final String prize; // VD: Giải Nhì, Huy chương Bạc, Top 10
  final String judgeFeedback; // Nhận xét của giám khảo
  final String status; // 'Đã công bố', 'Đang chấm'
  final DateTime announcedDate;

  ContestResult({
    required this.id,
    required this.contestTitle,
    required this.submissionTitle,
    required this.score,
    required this.prize,
    required this.judgeFeedback,
    required this.status,
    required this.announcedDate,
  });
}
