import 'package:flutter/material.dart';
import 'screens/contest_result_screen.dart';

void main() {
  runApp(const ContestResultApp());
}

class ContestResultApp extends StatelessWidget {
  const ContestResultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contest Result & Feedback (FE16 - WBS 16.3)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const ContestResultScreen(),
    );
  }
}
