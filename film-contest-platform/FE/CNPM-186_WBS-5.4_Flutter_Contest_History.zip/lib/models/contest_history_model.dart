class ContestHistoryItem {
  final String id;
  final String contestTitle;
  final String organizer;
  final String submissionTitle;
  final String joinedDate;
  final String status; // 'Đang diễn ra', 'Đã kết thúc'
  final bool isPublished; // Kết quả đã công bố hay chưa
  final double? score;
  final String? prize;
  final String? judgeFeedback;

  ContestHistoryItem({
    required this.id,
    required this.contestTitle,
    required this.organizer,
    required this.submissionTitle,
    required this.joinedDate,
    required this.status,
    required this.isPublished,
    this.score,
    this.prize,
    this.judgeFeedback,
  });
}
