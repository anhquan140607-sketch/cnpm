import 'package:flutter/material.dart';
import 'screens/contest_history_screen.dart';

void main() {
  runApp(const ContestHistoryApp());
}

class ContestHistoryApp extends StatelessWidget {
  const ContestHistoryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contest History Manager (FE5 - WBS 5.4)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const ContestHistoryScreen(),
    );
  }
}
