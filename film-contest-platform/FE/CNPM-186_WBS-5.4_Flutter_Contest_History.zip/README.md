# [CNPM-186 / WBS 5.4] Flutter: Lịch sử cuộc thi của thí sinh (FE5 - SRS FR-5.5)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                       # Điểm khởi chạy ứng dụng
├── models/
│   └── contest_history_model.dart  # Model dữ liệu lịch sử cuộc thi & kết quả
└── screens/
    └── contest_history_screen.dart # Màn hình danh sách cuộc thi đã tham gia, bộ lọc trạng thái và hiển thị kết quả sau khi công bố (SRS FR-5.5)
```

## 2. Tính năng chính đáp ứng SRS FR-5.5
- **Danh sách cuộc thi đã tham gia**: Thí sinh dễ dàng theo dõi toàn bộ các cuộc thi nhiếp ảnh film mà mình từng đăng ký và nộp bài.
- **Hiển thị kết quả sau khi công bố**: Kết quả chấm điểm, giải thưởng và nhận xét của giám khảo chỉ hiển thị minh bạch sau khi ban tổ chức chính thức công bố kết quả (`isPublished = true`).
