import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const FilmContestShellApp());
}

class FilmContestShellApp extends StatelessWidget {
  const FilmContestShellApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Film Contest Shell (FE7 - WBS 7.5)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const LoginScreen(),
    );
  }
}
