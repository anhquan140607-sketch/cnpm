# [CNPM-10 / WBS 7.5] Flutter: Khung ứng dụng, Đăng nhập, Xem và Đăng ký cuộc thi (FE7 - SRS FR-7.6)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                     # Điểm khởi chạy ứng dụng (Entry point)
└── screens/
    ├── login_screen.dart         # Màn hình đăng nhập (Xác thực tài khoản thí sinh)
    ├── home_screen.dart          # Khung ứng dụng chính (App Shell với NavigationBar)
    ├── contest_list_screen.dart  # Màn hình danh sách cuộc thi & tính năng đăng ký/hủy đăng ký (SRS FR-7.6)
    ├── my_submissions_screen.dart# Màn hình theo dõi bài dự thi đã nộp
    └── profile_screen.dart       # Màn hình tài khoản & đăng xuất
```

## 2. Tính năng chính
- **Khung ứng dụng (App Shell)**: Điều hướng linh hoạt giữa các tab chính qua `NavigationBar`.
- **Đăng nhập (`LoginScreen`)**: Giao diện xác thực tài khoản thí sinh (`anhquan140607@gmail.com`).
- **Xem và Đăng ký cuộc thi (`ContestListScreen`)**: Đáp ứng SRS FR-7.6, cho phép thí sinh duyệt qua danh sách các cuộc thi nhiếp ảnh film, xem thông tin chi tiết giải thưởng, hạn nộp và thực hiện đăng ký/hủy đăng ký tham gia trực tiếp.
