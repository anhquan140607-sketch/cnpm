# [CNPM-XXX / WBS 7.5] Flutter: Chọn ảnh, nhập metadata, xem trạng thái bài nộp trên mobile (FE7 - SRS FR-7.6)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                          # Điểm khởi chạy ứng dụng
├── models/
│   └── submission_model.dart          # Model bài dự thi & thông số metadata phim
└── screens/
    └── submission_manager_screen.dart # Màn hình chọn ảnh, nhập metadata, chỉnh sửa và theo dõi trạng thái bài nộp (SRS FR-7.6)
```

## 2. Tính năng chính đáp ứng SRS FR-7.6
- **Chọn ảnh & Nộp bài**: Hỗ trợ chọn ảnh từ thư viện/máy ảnh để tham gia các cuộc thi nhiếp ảnh film.
- **Nhập Metadata phim chi tiết**: Cung cấp biểu mẫu nhập tiêu đề, loại film (Film Stock), ISO, tốc độ màn trập, khẩu độ và địa điểm chụp.
- **Xem trạng thái bài nộp**: Theo dõi trực quan trạng thái xét duyệt của bài dự thi (*Đã duyệt*, *Đang chấm*) ngay trên giao diện mobile.
