class ContestSubmission {
  final String id;
  final String contestTitle;
  final String imagePath;
  final String title;
  final String filmStock;
  final int iso;
  final String shutterSpeed;
  final String aperture;
  final String location;
  final String status; // 'Đang chấm', 'Đã duyệt', 'Bị từ chối'
  final DateTime submittedAt;

  ContestSubmission({
    required this.id,
    required this.contestTitle,
    required this.imagePath,
    required this.title,
    required this.filmStock,
    required this.iso,
    required this.shutterSpeed,
    required this.aperture,
    required this.location,
    required this.status,
    required this.submittedAt,
  });

  ContestSubmission copyWith({
    String? contestTitle,
    String? imagePath,
    String? title,
    String? filmStock,
    int? iso,
    String? shutterSpeed,
    String? aperture,
    String? location,
    String? status,
  }) {
    return ContestSubmission(
      id: id,
      contestTitle: contestTitle ?? this.contestTitle,
      imagePath: imagePath ?? this.imagePath,
      title: title ?? this.title,
      filmStock: filmStock ?? this.filmStock,
      iso: iso ?? this.iso,
      shutterSpeed: shutterSpeed ?? this.shutterSpeed,
      aperture: aperture ?? this.aperture,
      location: location ?? this.location,
      status: status ?? this.status,
      submittedAt: submittedAt,
    );
  }
}
