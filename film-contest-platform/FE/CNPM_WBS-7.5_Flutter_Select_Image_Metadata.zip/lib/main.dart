import 'package:flutter/material.dart';
import 'screens/submission_manager_screen.dart';

void main() {
  runApp(const SubmissionApp());
}

class SubmissionApp extends StatelessWidget {
  const SubmissionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Submission & Metadata Manager (FE7 - WBS 7.5)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const SubmissionManagerScreen(),
    );
  }
}
