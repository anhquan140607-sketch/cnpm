# [CNPM-83 / WBS 6.3] Flutter: Màn hình quản lý Film Roll và Frame (FE6 - SRS FR-6.4)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                          # Entry point chạy giao diện FE6
├── models/
│   ├── film_roll_model.dart           # Model dữ liệu FilmRoll & FilmFrame
│   └── mock_film_data.dart            # Dữ liệu mẫu (Kodak Portra 400, Ilford HP5)
├── widgets/
│   └── film_roll_card.dart            # Widget thẻ hiển thị thông tin từng cuộn film
└── screens/
    ├── film_roll_list_screen.dart     # Màn hình danh sách cuộn film, lọc trạng thái & lắp cuộn mới
    └── film_frame_grid_screen.dart    # Màn hình Contact Sheet (Light Table) quản lý từng Frame & nộp thi
```

## 2. Các chức năng đã hoàn thiện (đáp ứng SRS FR-6.4)
- **Quản lý danh sách cuộn film (`FilmRollListScreen`)**:
  - Lọc theo trạng thái: *Tất cả*, *Đang chụp*, *Đã tráng*, *Đã nộp*.
  - Hiển thị tiến độ số kiểu đã chụp (`exposedCount / totalFrames`), loại film, ISO, cuộc thi liên kết.
  - Tạo / lắp cuộn film mới (24 hoặc 36 kiểu).
- **Quản lý từng khung hình (`FilmFrameGridScreen`)**:
  - Giao diện Contact Sheet mô phỏng bàn soi film (Light Table) và dải đục lỗ phim 35mm.
  - Xem, tải ảnh scan, nhập/chỉnh sửa metadata thủ công cho từng frame (Tiêu đề, địa điểm, tốc độ màn trập, khẩu độ, ghi chú kỹ thuật).
  - Đánh dấu chọn frame để nộp bài dự thi trực tiếp từ cuộn film.
