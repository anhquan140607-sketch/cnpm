import 'package:flutter/material.dart';
import '../models/film_roll_model.dart';

class FilmRollCard extends StatelessWidget {
  final FilmRoll roll;
  final VoidCallback onTap;

  const FilmRollCard({
    super.key,
    required this.roll,
    required this.onTap,
  });

  Color _getStatusColor(FilmRollStatus status) {
    switch (status) {
      case FilmRollStatus.inProgress:
        return Colors.amber.shade700;
      case FilmRollStatus.developed:
        return Colors.teal.shade600;
      case FilmRollStatus.submitted:
        return Colors.indigo.shade600;
    }
  }

  String _getStatusLabel(FilmRollStatus status) {
    switch (status) {
      case FilmRollStatus.inProgress:
        return 'Đang chụp';
      case FilmRollStatus.developed:
        return 'Đã tráng / Scan';
      case FilmRollStatus.submitted:
        return 'Đã nộp bài';
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(roll.status);

    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: Tên cuộn film & Trạng thái
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      roll.rollName,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor.withOpacity(0.5)),
                    ),
                    child: Text(
                      _getStatusLabel(roll.status),
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),

              // Thông số film
              Row(
                children: [
                  const Icon(Icons.camera_roll_outlined, size: 16, color: Colors.grey),
                  const SizedBox(width: 6),
                  Text(
                    '${roll.filmStock} • ISO ${roll.iso} • ${roll.totalFrames} kiểu',
                    style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                  ),
                ],
              ),
              const SizedBox(height: 4),

              // Cuộc thi liên kết
              Row(
                children: [
                  const Icon(Icons.emoji_events_outlined, size: 16, color: Colors.orange),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Cuộc thi: ${roll.contestName}',
                      style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Thanh tiến độ số kiểu đã chụp
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Đã chụp: ${roll.exposedCount}/${roll.totalFrames} frames',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  ),
                  Text(
                    'Đã chọn nộp: ${roll.submittedCount} ảnh',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.indigo.shade600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: roll.progress,
                  minHeight: 7,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.amber.shade800),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
