import 'package:flutter/material.dart';
import 'screens/film_roll_list_screen.dart';

void main() {
  runApp(const FilmContestApp());
}

class FilmContestApp extends StatelessWidget {
  const FilmContestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Film Roll & Frame Manager (FE6 - WBS 6.3)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const FilmRollListScreen(),
    );
  }
}
