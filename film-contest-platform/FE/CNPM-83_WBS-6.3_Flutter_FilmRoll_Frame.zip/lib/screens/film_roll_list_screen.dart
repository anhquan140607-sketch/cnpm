import 'package:flutter/material.dart';
import '../models/film_roll_model.dart';
import '../models/mock_film_data.dart';
import '../widgets/film_roll_card.dart';
import 'film_frame_grid_screen.dart';

class FilmRollListScreen extends StatefulWidget {
  const FilmRollListScreen({super.key});

  @override
  State<FilmRollListScreen> createState() => _FilmRollListScreenState();
}

class _FilmRollListScreenState extends State<FilmRollListScreen> {
  late List<FilmRoll> _filmRolls;
  String _selectedFilter = 'Tất cả';

  @override
  void initState() {
    super.initState();
    _filmRolls = MockFilmData.getSampleRolls();
  }

  List<FilmRoll> get _filteredRolls {
    if (_selectedFilter == 'Đang chụp') {
      return _filmRolls.where((r) => r.status == FilmRollStatus.inProgress).toList();
    } else if (_selectedFilter == 'Đã tráng') {
      return _filmRolls.where((r) => r.status == FilmRollStatus.developed).toList();
    } else if (_selectedFilter == 'Đã nộp') {
      return _filmRolls.where((r) => r.status == FilmRollStatus.submitted).toList();
    }
    return _filmRolls;
  }

  void _showAddFilmRollDialog() {
    final nameController = TextEditingController();
    final stockController = TextEditingController(text: 'Kodak Gold 200');
    final contestController = TextEditingController(text: 'Nét Đẹp Đô Thị Việt Nam 2026');
    int selectedIso = 200;
    int selectedFrames = 36;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Lắp Cuộn Film Mới (Load Film Roll)',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Tên cuộn film / Ghi chú chủ đề',
                      hintText: 'VD: Cuộn #03 - Chiều Hoàng Hôn',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: stockController,
                    decoration: const InputDecoration(
                      labelText: 'Loại Film (Film Stock)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: contestController,
                    decoration: const InputDecoration(
                      labelText: 'Cuộc thi dự kiến tham gia',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          value: selectedIso,
                          decoration: const InputDecoration(
                            labelText: 'ISO',
                            border: OutlineInputBorder(),
                          ),
                          items: [100, 200, 400, 800, 1600]
                              .map((iso) => DropdownMenuItem(value: iso, child: Text('ISO $iso')))
                              .toList(),
                          onChanged: (val) => setModalState(() => selectedIso = val!),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          value: selectedFrames,
                          decoration: const InputDecoration(
                            labelText: 'Số kiểu (Frames)',
                            border: OutlineInputBorder(),
                          ),
                          items: [24, 36]
                              .map((f) => DropdownMenuItem(value: f, child: Text('$f kiểu')))
                              .toList(),
                          onChanged: (val) => setModalState(() => selectedFrames = val!),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber.shade800,
                        foregroundColor: Colors.white,
                      ),
                      icon: const Icon(Icons.add_circle_outline),
                      label: const Text('Tạo Cuộn Film'),
                      onPressed: () {
                        final newRoll = FilmRoll(
                          id: 'ROLL-${_filmRolls.length + 1}'.padLeft(8, '0'),
                          rollName: nameController.text.trim().isEmpty
                              ? 'Cuộn #0${_filmRolls.length + 1}'
                              : nameController.text.trim(),
                          filmStock: stockController.text.trim(),
                          iso: selectedIso,
                          totalFrames: selectedFrames,
                          contestName: contestController.text.trim(),
                          status: FilmRollStatus.inProgress,
                          loadedDate: DateTime.now(),
                          frames: List.generate(
                            selectedFrames,
                            (i) => FilmFrame(frameNumber: i + 1),
                          ),
                        );
                        setState(() => _filmRolls.insert(0, newRoll));
                        Navigator.pop(ctx);
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final filters = ['Tất cả', 'Đang chụp', 'Đã tráng', 'Đã nộp'];

    return Scaffold(
      backgroundColor: const Color(0xFFF6F5F2),
      appBar: AppBar(
        title: const Text('Quản Lý Cuộn Film & Frame'),
        backgroundColor: const Color(0xFF1E1E1E),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Thanh Filter trạng thái cuộn film
          Container(
            height: 54,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final f = filters[index];
                final isSelected = _selectedFilter == f;
                return ChoiceChip(
                  label: Text(f),
                  selected: isSelected,
                  selectedColor: Colors.amber.shade800,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : Colors.black87,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  ),
                  onSelected: (_) => setState(() => _selectedFilter = f),
                );
              },
            ),
          ),

          // Danh sách cuộn film
          Expanded(
            child: _filteredRolls.isEmpty
                ? const Center(child: Text('Chưa có cuộn film nào trong mục này.'))
                : ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: _filteredRolls.length,
                    itemBuilder: (context, index) {
                      final roll = _filteredRolls[index];
                      return FilmRollCard(
                        roll: roll,
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => FilmFrameGridScreen(roll: roll),
                            ),
                          );
                          setState(() {});
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.amber.shade800,
        foregroundColor: Colors.white,
        onPressed: _showAddFilmRollDialog,
        icon: const Icon(Icons.camera_roll),
        label: const Text('Lắp cuộn mới'),
      ),
    );
  }
}
