import '../models/film_roll_model.dart';

class MockFilmData {
  static List<FilmRoll> getSampleRolls() {
    return [
      FilmRoll(
        id: 'ROLL-001',
        rollName: 'Cuộn #01 - Sài Gòn Sáng Sớm',
        filmStock: 'Kodak Portra 400',
        iso: 400,
        totalFrames: 36,
        contestName: 'Nét Đẹp Đô Thị Việt Nam 2026',
        status: FilmRollStatus.developed,
        loadedDate: DateTime(2026, 11, 10),
        frames: List.generate(36, (index) {
          final num = index + 1;
          if (num <= 18) {
            return FilmFrame(
              frameNumber: num,
              imageUrl: 'https://picsum.photos/seed/film_${num}/600/400',
              title: 'Khung hình #$num - Phố cổ',
              location: 'Quận 1, TP. Hồ Chí Minh',
              shutterSpeed: '1/250s',
              aperture: 'f/2.8',
              notes: 'Ánh nắng xiên buổi sáng, đo sáng +0.5 EV',
              capturedAt: DateTime(2026, 11, 12, 7, num),
              isSubmitted: num == 3 || num == 12,
            );
          }
          return FilmFrame(frameNumber: num);
        }),
      ),
      FilmRoll(
        id: 'ROLL-002',
        rollName: 'Cuộn #02 - Chân Dung Đời Thường',
        filmStock: 'Ilford HP5 Plus 400 (B&W)',
        iso: 400,
        totalFrames: 24,
        contestName: 'Khoảnh Khắc Đen Trắng 2026',
        status: FilmRollStatus.inProgress,
        loadedDate: DateTime(2026, 11, 15),
        frames: List.generate(24, (index) {
          final num = index + 1;
          if (num <= 10) {
            return FilmFrame(
              frameNumber: num,
              imageUrl: 'https://picsum.photos/seed/bw_${num}/600/400',
              title: 'Chân dung #$num',
              location: 'Chợ Bến Thành',
              shutterSpeed: '1/500s',
              aperture: 'f/4.0',
              notes: 'Film đen trắng tương phản cao',
              capturedAt: DateTime(2026, 11, 16, 16, num),
              isSubmitted: false,
            );
          }
          return FilmFrame(frameNumber: num);
        }),
      ),
    ];
  }
}
