class FilmFrame {
  final int frameNumber;
  final String? imageUrl;
  final String? title;
  final String? location;
  final String? shutterSpeed;
  final String? aperture;
  final String? notes;
  final DateTime? capturedAt;
  final bool isSubmitted;

  FilmFrame({
    required this.frameNumber,
    this.imageUrl,
    this.title,
    this.location,
    this.shutterSpeed,
    this.aperture,
    this.notes,
    this.capturedAt,
    this.isSubmitted = false,
  });

  bool get isExposed => imageUrl != null && imageUrl!.isNotEmpty;

  FilmFrame copyWith({
    int? frameNumber,
    String? imageUrl,
    String? title,
    String? location,
    String? shutterSpeed,
    String? aperture,
    String? notes,
    DateTime? capturedAt,
    bool? isSubmitted,
  }) {
    return FilmFrame(
      frameNumber: frameNumber ?? this.frameNumber,
      imageUrl: imageUrl ?? this.imageUrl,
      title: title ?? this.title,
      location: location ?? this.location,
      shutterSpeed: shutterSpeed ?? this.shutterSpeed,
      aperture: aperture ?? this.aperture,
      notes: notes ?? this.notes,
      capturedAt: capturedAt ?? this.capturedAt,
      isSubmitted: isSubmitted ?? this.isSubmitted,
    );
  }
}

enum FilmRollStatus {
  inProgress, // Đang chụp
  developed,  // Đã tráng / scan
  submitted,  // Đã nộp dự thi
}

class FilmRoll {
  final String id;
  final String rollName;
  final String filmStock; // VD: Kodak Portra 400, Fujifilm C200, Ilford HP5
  final int iso;
  final int totalFrames; // 24 hoặc 36 kiểu
  final String contestName;
  final FilmRollStatus status;
  final DateTime loadedDate;
  final List<FilmFrame> frames;

  FilmRoll({
    required this.id,
    required this.rollName,
    required this.filmStock,
    required this.iso,
    required this.totalFrames,
    required this.contestName,
    required this.status,
    required this.loadedDate,
    required this.frames,
  });

  int get exposedCount => frames.where((f) => f.isExposed).length;
  int get submittedCount => frames.where((f) => f.isSubmitted).length;
  double get progress => totalFrames == 0 ? 0 : exposedCount / totalFrames;
}
