class JudgeSubmissionScore {
  final String id;
  final String submissionTitle;
  final String contestantName;
  final String filmStock;
  final String imageUrl;
  double score;
  String feedback;
  bool isConfirmed; // Giám khảo xác nhận
  bool isLocked;    // Điểm đã xác nhận bị khóa (không cho sửa)

  JudgeSubmissionScore({
    required this.id,
    required this.submissionTitle,
    required this.contestantName,
    required this.filmStock,
    required this.imageUrl,
    this.score = 0.0,
    this.feedback = '',
    this.isConfirmed = false,
    this.isLocked = false,
  });
}
