import 'package:flutter/material.dart';
import 'screens/score_lock_screen.dart';

void main() {
  runApp(const ScoreLockApp());
}

class ScoreLockApp extends StatelessWidget {
  const ScoreLockApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Score Lock Manager (FE10 - WBS 10.5)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const ScoreLockScreen(),
    );
  }
}
