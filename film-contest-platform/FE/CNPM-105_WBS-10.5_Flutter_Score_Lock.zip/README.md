# [CNPM-105 / WBS 10.5] Flutter: Giám khảo xác nhận, điểm đã xác nhận bị khóa (FE10 - SRS FR-10.5)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                      # Điểm khởi chạy ứng dụng
├── models/
│   └── score_lock_model.dart      # Model lưu điểm số, trạng thái xác nhận & khóa điểm của giám khảo
└── screens/
    └── score_lock_screen.dart     # Màn hình danh sách bài thi, chấm điểm, xác nhận và khóa điểm cứng (SRS FR-10.5)
```

## 2. Tính năng chính đáp ứng SRS FR-10.5
- **Xác nhận của Giám khảo**: Giám khảo nhập điểm và nhận xét cho từng tác phẩm dự thi.
- **Khóa điểm sau khi xác nhận**: Khi giám khảo bật công tắc "Xác nhận & Khóa điểm", hệ thống sẽ khóa cứng kết quả (`isLocked = true`), ngăn chặn mọi thao tác chỉnh sửa tiếp theo, bảo mật tính khách quan của bảng điểm.
