# [CNPM-162 / WBS 8.3] Hàng đợi bài bị gắn cờ (FE8 - SRS FR-8.4)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                             # Điểm khởi chạy ứng dụng kiểm duyệt
├── models/
│   └── flagged_submission_model.dart     # Model bài dự thi nghi vấn, mức độ cảnh báo & lý do gắn cờ
└── screens/
    └── flagged_queue_screen.dart         # Màn hình danh sách bài nghi vấn kèm lý do gắn cờ & xử lý kiểm duyệt (SRS FR-8.4)
```

## 2. Chức năng chính đáp ứng SRS FR-8.4
- **Danh sách hàng đợi bài nghi vấn (`FlaggedQueueScreen`)**: Hiển thị các bài dự thi bị hệ thống AI hoặc người dùng gắn cờ, kèm mức độ nghi vấn (*Nghi vấn cao*, *Trung bình*, *Cảnh báo nhẹ*) và điểm bất thường AI (%).
- **Hiển thị rõ lý do gắn cờ**: Mỗi thẻ bài thi và bảng chi tiết đều liệt kê cụ thể các lý do nghi vấn (VD: chỉnh sửa bằng AI/Photoshop, sai tỷ lệ khung hình phim 35mm, thiếu ảnh dải âm bản đối chiếu, trùng lặp ảnh).
- **Xử lý kiểm duyệt**: Cho phép kiểm duyệt viên lọc trạng thái (*Chờ xử lý*, *Đã gỡ cờ*, *Đã từ chối*), ghi chú nhận xét và quyết định **Gỡ cờ (Hợp lệ)** hoặc **Từ chối bài**.
