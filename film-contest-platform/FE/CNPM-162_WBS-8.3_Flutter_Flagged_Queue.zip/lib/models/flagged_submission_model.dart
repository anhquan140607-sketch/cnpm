enum FlagStatus {
  pending,   // Chờ duyệt / Kiểm duyệt viên xem xét
  approved,  // Hợp lệ (Gỡ cờ - Cho phép dự thi)
  rejected,  // Vi phạm (Từ chối / Loại bài)
}

enum FlagSeverity {
  high,      // Nghi vấn cao (VD: AI phát hiện chỉnh sửa nặng / EXIF giả mạo)
  medium,    // Nghi vấn trung bình (VD: Thiếu thông số cuộn film / Sai kích thước)
  low,       // Cảnh báo nhẹ (VD: Trùng lặp góc chụp / Nghi vấn bản quyền)
}

class FlaggedSubmission {
  final String id;
  final String submissionTitle;
  final String contestantName;
  final String contestantEmail;
  final String contestName;
  final String filmStock;
  final String imageUrl;
  final List<String> flagReasons;
  final double aiAnomalyScore; // 0.0 -> 100.0 (%)
  final FlagSeverity severity;
  final DateTime flaggedAt;
  FlagStatus status;
  String? moderatorNote;

  FlaggedSubmission({
    required this.id,
    required this.submissionTitle,
    required this.contestantName,
    required this.contestantEmail,
    required this.contestName,
    required this.filmStock,
    required this.imageUrl,
    required this.flagReasons,
    required this.aiAnomalyScore,
    required this.severity,
    required this.flaggedAt,
    this.status = FlagStatus.pending,
    this.moderatorNote,
  });
}
