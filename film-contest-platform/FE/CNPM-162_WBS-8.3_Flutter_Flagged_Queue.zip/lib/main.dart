import 'package:flutter/material.dart';
import 'screens/flagged_queue_screen.dart';

void main() {
  runApp(const FlaggedQueueApp());
}

class FlaggedQueueApp extends StatelessWidget {
  const FlaggedQueueApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flagged Submissions Queue (FE8 - WBS 8.3)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.red.shade700,
      ),
      home: const FlaggedQueueScreen(),
    );
  }
}
