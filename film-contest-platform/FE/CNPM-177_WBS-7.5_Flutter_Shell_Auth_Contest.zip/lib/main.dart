import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const FilmContestApp());
}

class FilmContestApp extends StatelessWidget {
  const FilmContestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Film Contest App Shell (FE7 - WBS 7.5)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const LoginScreen(),
    );
  }
}
