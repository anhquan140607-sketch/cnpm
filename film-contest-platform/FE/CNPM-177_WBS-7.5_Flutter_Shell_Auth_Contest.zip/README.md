# [CNPM-177 / WBS 7.5] Flutter: Khung ứng dụng, đăng nhập, danh sách cuộc thi (FE7 - SRS FR-7.6)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                     # Điểm khởi chạy ứng dụng (Entry point)
└── screens/
    ├── login_screen.dart         # Màn hình đăng nhập tài khoản thí sinh
    ├── home_screen.dart          # Khung ứng dụng (App Shell với NavigationBar)
    ├── contest_list_screen.dart  # Danh sách cuộc thi & tính năng đăng ký / hủy đăng ký (SRS FR-7.6)
    ├── my_submissions_screen.dart# Theo dõi bài dự thi đã nộp
    └── profile_screen.dart       # Quản lý tài khoản & đăng xuất
```

## 2. Các chức năng chính đáp ứng SRS FR-7.6
- **Khung ứng dụng (App Shell)**: Điều hướng linh hoạt giữa các màn hình chính qua thanh `NavigationBar`.
- **Đăng nhập (`LoginScreen`)**: Xác thực tài khoản thí sinh (`anhquan140607@gmail.com`).
- **Xem và Đăng ký cuộc thi (`ContestListScreen`)**: Cho phép thí sinh duyệt qua danh sách cuộc thi nhiếp ảnh film, xem thông tin giải thưởng, hạn nộp và thực hiện đăng ký / hủy đăng ký trực tiếp.
