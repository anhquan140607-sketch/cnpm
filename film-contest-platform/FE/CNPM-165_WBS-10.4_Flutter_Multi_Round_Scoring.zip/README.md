# [CNPM-165 / WBS 10.4] Flutter: Cấu hình nhiều vòng chấm (FE10 - SRS FR-10.4)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                           # Điểm khởi chạy ứng dụng
├── models/
│   └── round_model.dart                # Model dữ liệu vòng chấm (Preliminary, Shortlist, Finals) & bài thi
└── screens/
    └── multi_round_manager_screen.dart # Màn hình quản lý cấu hình nhiều vòng chấm, chấm điểm & chọn bài vào vòng sau (SRS FR-10.4)
```

## 2. Các chức năng chính đáp ứng SRS FR-10.4
- **Quản lý cấu hình nhiều vòng chấm (`MultiRoundManagerScreen`)**: Hỗ trợ phân loại các vòng thi rõ ràng (*Vòng Loại*, *Vòng Shortlist*, *Vòng Chung Kết*).
- **Chấm điểm và Chọn bài vào vòng sau**: Cho phép ban giám khảo/quản trị viên chấm điểm từng bài dự thi theo từng vòng và thực hiện thao tác chuyển trạng thái (đưa bài vào Shortlist / vòng kế tiếp hoặc loại bài).
