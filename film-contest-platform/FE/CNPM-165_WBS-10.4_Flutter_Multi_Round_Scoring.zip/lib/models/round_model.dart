enum ContestRoundStage {
  preliminary, // Vòng loại
  shortlist,   // Vòng Shortlist (Top chọn lọc)
  finalRound,  // Vòng Chung kết
}

class SubmissionItem {
  final String id;
  final String title;
  final String author;
  final String filmStock;
  final String imageUrl;
  double score;
  bool isQualifiedToNextRound;
  String roundStatus; // 'Chờ chấm', 'Đã qua vòng', 'Đã loại'

  SubmissionItem({
    required this.id,
    required this.title,
    required this.author,
    required this.filmStock,
    required this.imageUrl,
    this.score = 0.0,
    this.isQualifiedToNextRound = false,
    this.roundStatus = 'Chờ chấm',
  });
}

class ContestRound {
  final String id;
  final ContestRoundStage stage;
  final String roundName;
  final String description;
  bool isCurrentActive;
  List<SubmissionItem> submissions;

  ContestRound({
    required this.id,
    required this.stage,
    required this.roundName,
    required this.description,
    this.isCurrentActive = false,
    required this.submissions,
  });
}
