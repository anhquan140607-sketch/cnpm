import 'package:flutter/material.dart';
import 'screens/multi_round_manager_screen.dart';

void main() {
  runApp(const MultiRoundApp());
}

class MultiRoundApp extends StatelessWidget {
  const MultiRoundApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi-Round Scoring Manager (FE10 - WBS 10.4)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const MultiRoundManagerScreen(),
    );
  }
}
