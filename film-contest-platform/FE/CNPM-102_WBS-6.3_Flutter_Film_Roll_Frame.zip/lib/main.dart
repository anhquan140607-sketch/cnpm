import 'package:flutter/material.dart';
import 'screens/film_roll_manager_screen.dart';

void main() {
  runApp(const FilmRollApp());
}

class FilmRollApp extends StatelessWidget {
  const FilmRollApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Film Roll & Frame Manager (FE6 - WBS 6.3)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const FilmRollManagerScreen(),
    );
  }
}
