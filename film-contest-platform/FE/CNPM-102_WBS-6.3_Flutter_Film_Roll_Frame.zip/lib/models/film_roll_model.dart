class FilmFrame {
  final int frameNumber;
  final String? imageUrl;
  final String? title;
  final String? location;
  final String? shutterSpeed;
  final String? aperture;
  final String? notes;
  final bool isSubmitted;

  FilmFrame({
    required this.frameNumber,
    this.imageUrl,
    this.title,
    this.location,
    this.shutterSpeed,
    this.aperture,
    this.notes,
    this.isSubmitted = false,
  });

  bool get isExposed => imageUrl != null && imageUrl!.isNotEmpty;

  FilmFrame copyWith({
    int? frameNumber,
    String? imageUrl,
    String? title,
    String? location,
    String? shutterSpeed,
    String? aperture,
    String? notes,
    bool? isSubmitted,
  }) {
    return FilmFrame(
      frameNumber: frameNumber ?? this.frameNumber,
      imageUrl: imageUrl ?? this.imageUrl,
      title: title ?? this.title,
      location: location ?? this.location,
      shutterSpeed: shutterSpeed ?? this.shutterSpeed,
      aperture: aperture ?? this.aperture,
      notes: notes ?? this.notes,
      isSubmitted: isSubmitted ?? this.isSubmitted,
    );
  }
}

class FilmRoll {
  final String id;
  final String rollName;
  final String filmStock;
  final int iso;
  final int totalFrames;
  final String contestName;
  final List<FilmFrame> frames;

  FilmRoll({
    required this.id,
    required this.rollName,
    required this.filmStock,
    required this.iso,
    required this.totalFrames,
    required this.contestName,
    required this.frames,
  });

  int get exposedCount => frames.where((f) => f.isExposed).length;
  int get submittedCount => frames.where((f) => f.isSubmitted).length;
}
