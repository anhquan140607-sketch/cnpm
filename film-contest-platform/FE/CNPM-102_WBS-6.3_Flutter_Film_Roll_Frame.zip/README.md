# [CNPM-102 / WBS 6.3] Flutter: Quản lý cuộn film và khung hình (FE6 - SRS FR-6.4)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                          # Entry point chạy giao diện FE6
├── models/
│   └── film_roll_model.dart           # Model dữ liệu FilmRoll & FilmFrame
└── screens/
    └── film_roll_manager_screen.dart  # Màn hình Contact Sheet (Light Table) quản lý từng Frame, tải ảnh scan & nộp thi
```

## 2. Tính năng chính đáp ứng SRS FR-6.4
- **Quản lý cuộn film & Contact Sheet**: Giao diện bàn soi film (Light Table) trực quan với dải khung hình 35mm.
- **Quản lý Frame chi tiết**: Xem trạng thái đã chụp/trống, tải ảnh scan, nhập metadata (tiêu đề, địa điểm, tốc độ màn trập, khẩu độ, ghi chú).
- **Chọn khung hình nộp thi**: Đánh dấu chọn các frame ưng ý trực tiếp trên cuộn film để gửi bài dự thi.
