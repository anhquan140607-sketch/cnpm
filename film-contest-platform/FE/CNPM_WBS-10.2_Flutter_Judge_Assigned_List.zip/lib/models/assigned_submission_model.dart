class AssignedSubmission {
  final String id;
  final String submissionTitle;
  final String contestantName;
  final String contestName;
  final String filmStock;
  final int iso;
  final String shutterSpeed;
  final String aperture;
  final String location;
  final String imageUrl;
  final DateTime submittedAt;
  double score;
  String status; // 'Chưa chấm', 'Đang chấm', 'Đã hoàn thành'
  String feedback;

  AssignedSubmission({
    required this.id,
    required this.submissionTitle,
    required this.contestantName,
    required this.contestName,
    required this.filmStock,
    required this.iso,
    required this.shutterSpeed,
    required this.aperture,
    required this.location,
    required this.imageUrl,
    required this.submittedAt,
    this.score = 0.0,
    this.status = 'Chưa chấm',
    this.feedback = '',
  });
}
