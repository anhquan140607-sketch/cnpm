import 'package:flutter/material.dart';
import 'screens/judge_assigned_list_screen.dart';

void main() {
  runApp(const JudgeAssignedApp());
}

class JudgeAssignedApp extends StatelessWidget {
  const JudgeAssignedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Judge Assigned List & Grading (FE10 - WBS 10.2)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.amber.shade800,
      ),
      home: const JudgeAssignedListScreen(),
    );
  }
}
