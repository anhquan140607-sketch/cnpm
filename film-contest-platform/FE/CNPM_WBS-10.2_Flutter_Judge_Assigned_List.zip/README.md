# [CNPM-XXX / WBS 10.2] Flutter: Danh sách bài được giao, ảnh phóng to, metadata phim, tiến độ chấm (FE10 - SRS FR-10.2)

## 1. Cấu trúc thư mục
```text
lib/
├── main.dart                          # Điểm khởi chạy ứng dụng
├── models/
│   └── assigned_submission_model.dart # Model lưu trữ thông tin bài thi được giao & metadata phim
└── screens/
    └── judge_assigned_list_screen.dart# Màn hình danh sách bài được giao, thanh tiến độ, ảnh phóng to, metadata & chấm điểm (SRS FR-10.2)
```

## 2. Tính năng chính đáp ứng SRS FR-10.2
- **Danh sách bài được giao & Tiến độ chấm**: Hiển thị danh sách các tác phẩm được phân công cho giám khảo kèm thanh tiến độ hoàn thành chung.
- **Ảnh phóng to & Metadata phim**: Hỗ trợ xem chi tiết thông số kỹ thuật máy film (Film stock, ISO, tốc độ màn trập, khẩu độ, địa điểm) và chạm để phóng to toàn màn hình (`InteractiveViewer`).
- **Chấm điểm & Nhận xét**: Cho phép giám khảo nhập điểm, viết nhận xét và cập nhật trạng thái hoàn thành bài chấm.
